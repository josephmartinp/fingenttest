<?php

namespace Container9KPdtzG;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderc9b89 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer509b3 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties00093 = [
        
    ];

    public function getConnection()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getConnection', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getMetadataFactory', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getExpressionBuilder', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'beginTransaction', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getCache', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getCache();
    }

    public function transactional($func)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'transactional', array('func' => $func), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->transactional($func);
    }

    public function commit()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'commit', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->commit();
    }

    public function rollback()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'rollback', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getClassMetadata', array('className' => $className), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'createQuery', array('dql' => $dql), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'createNamedQuery', array('name' => $name), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'createQueryBuilder', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'flush', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'clear', array('entityName' => $entityName), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->clear($entityName);
    }

    public function close()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'close', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->close();
    }

    public function persist($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'persist', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'remove', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'refresh', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'detach', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'merge', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getRepository', array('entityName' => $entityName), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'contains', array('entity' => $entity), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getEventManager', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getConfiguration', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'isOpen', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getUnitOfWork', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getProxyFactory', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'initializeObject', array('obj' => $obj), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'getFilters', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'isFiltersStateClean', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'hasFilters', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return $this->valueHolderc9b89->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer509b3 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderc9b89) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderc9b89 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderc9b89->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__get', ['name' => $name], $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        if (isset(self::$publicProperties00093[$name])) {
            return $this->valueHolderc9b89->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderc9b89;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderc9b89;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderc9b89;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderc9b89;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__isset', array('name' => $name), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderc9b89;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderc9b89;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__unset', array('name' => $name), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderc9b89;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderc9b89;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__clone', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        $this->valueHolderc9b89 = clone $this->valueHolderc9b89;
    }

    public function __sleep()
    {
        $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, '__sleep', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;

        return array('valueHolderc9b89');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer509b3 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer509b3;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer509b3 && ($this->initializer509b3->__invoke($valueHolderc9b89, $this, 'initializeProxy', array(), $this->initializer509b3) || 1) && $this->valueHolderc9b89 = $valueHolderc9b89;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderc9b89;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderc9b89;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
