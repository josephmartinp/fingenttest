<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;
use Symfony\Component\RateLimiter\RateLimiterFactory;
use Symfony\Component\RateLimiter\Storage\InMemoryStorage;

class ApiController extends AbstractController
{
    // if you're using service autowiring, the variable name must be:
    // "rate limiter name" (in camelCase) + "Limiter" suffix
    public function index(Request $request)
    {
        // create a limiter based on a unique identifier of the client
        // (e.g. the client's IP address, a username/email, an API key, etc.)
        $factory = new RateLimiterFactory([
            'id' => $request->getClientIp(),
            'policy' => 'token_bucket',
            'limit' => 2,
            'rate' => ['interval' => '1 seconds'],
        ], new InMemoryStorage());
        
        $limiter = $factory->create();
        
        // blocks until 1 token is free to use for this process
        $limiter->reserve(1)->wait();
        // ... execute the code
        // only claims 1 token if it's free at this moment (useful if you plan to skip this process)
        if ($limiter->consume(1)->isAccepted()) {
           dump('succes');die;
        }
        dump('error');die;
        return true;
        // you can also use the ensureAccepted() method - which throws a
        // RateLimitExceededException if the limit has been reached
        // $limiter->consume(1)->ensureAccepted();

        // ...
    }

    // ...
}
